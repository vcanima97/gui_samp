<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/css/materialize.min.css">
    <link rel="stylesheet" href="public/css/student_main.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Evaluate Me!</title>
  </head>

    <body>
