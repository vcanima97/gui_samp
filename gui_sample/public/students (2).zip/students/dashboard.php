<?php include 'header.php';?>

<nav>
  <div class="nav-wrapper green">
    <a href="#" class="brand-logo center">Evaluate Me!</a>
    <a href="#" style="margin-left: 5px;">Welcome, (Name of the Student), (Grade&Section)</a>
</nav>

  <div class="container">
    <ul class="collection with-header">
      <li class="collection-header"><h4>Teachers</h4></li>
      <li class="collection-item avatar">
        <i class="material-icons circle blue">person</i>
        <span class="title">Name of the Teacher</span>
        <p class="grey-text">Subject</p>
        <a href="evaluation_form.php" class="btn green secondary-content">
          Evaluate
        </a>
      </li>
      <li class="collection-item avatar">
        <i class="material-icons circle blue">person</i>
        <span class="title">Name of the Teacher</span>
        <p class="grey-text">Subject</p>
        <a href="" class="btn green secondary-content">
          Evaluate
        </a>
      </li>
      <li class="collection-item avatar">
        <i class="material-icons circle blue">person</i>
        <span class="title">Name of the Teacher</span>
        <p class="grey-text">Subject</p>
        <a href="" class="btn green secondary-content">
          Evaluate
        </a>
      </li>
      <li class="collection-item avatar">
        <i class="material-icons circle blue">person</i>
        <span class="title">Name of the Teacher</span>
        <p class="grey-text">Subject</p>
        <a href="" class="btn green secondary-content">
          Evaluate
        </a>
      </li>
      <li class="collection-item avatar">
        <i class="material-icons circle blue">person</i>
        <span class="title">Name of the Teacher</span>
        <p class="grey-text">Subject</p>
        <a href="" class="btn green secondary-content">
          Evaluate
        </a>
      </li>
      <li class="collection-item avatar">
        <i class="material-icons circle blue">person</i>
        <span class="title">Name of the Teacher</span>
        <p class="grey-text">Subject</p>
        <a href="" class="btn green secondary-content">
          Evaluate
        </a>
      </li>
      <li class="collection-item avatar">
        <i class="material-icons circle blue">person</i>
        <span class="title">Name of the Teacher</span>
        <p class="grey-text">Subject</p>
        <a href="" class="btn green secondary-content">
          Evaluate
        </a>
      </li>
      <li class="collection-item avatar">
        <i class="material-icons circle blue">person</i>
        <span class="title">Name of the Teacher</span>
        <p class="grey-text">Subject</p>
        <a href="" class="btn green secondary-content">
          Evaluate
        </a>
      </li>
    </ul>
  </div>

<?php include 'footer.php';?>
