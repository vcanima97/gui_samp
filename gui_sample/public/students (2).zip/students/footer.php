    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.100.2/js/materialize.min.js"></script>


    <footer class="page-footer green lighten">
         <div class="container">
           <div class="row">
             <div class="col l6 s12">
               <h5 class="white-text">Evaluation</h5>
               <p class="grey-text text-lighten-4">Sample Form</p>
             </div>
           </div>
         <div class="footer-copyright center">
           <div class="container">
           © 2019 GUI SAMPLE
           </div>
         </div>
       </footer>

  </body>
</html>
